<h1>SQLink &amp; AgileSparks JSBootcamp Group 4</h1>
<h2>Keywords</h2>
<h3>Javascript</h3>
<ol>
    <li>Dynamic Typing vs. Static Typing</li>  
    <li><code>null</code> vs. <code>undefined</code></li>  
    <li>== vs. ===</li>  
    <li>Hoisting</li>
    <li>Callback</li>
    <li><code>this</code> Keyword</li>
    <li><code>call</code> vs. <code>apply</code> vs. <code>bind</code></li>
    <li>Value vs. Reference</li>
    <li>Global Scope</li>
    <li>getter/setter</li>
</ol>
<h3>Git</h3>
<ol>
  <li>Repository</li>  
  <li>Branch</li>  
  <li>Pull Request</li>  
  <li>Checkout</li>  
  <li>Add</li>  
  <li>Pull</li>  
  <li>Push</li>  
  <li>Commit</li>  
</ol>
<h3>CSS</h3>
<ol>
  <li>Selectors</li>  
  <li>Priorities</li>  
  <li>Box Model</li>
</ol>