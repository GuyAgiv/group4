<p>use:
<ul>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/14</code></li>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/16</code></li>
 <li><code>group4/Modules/03 Front End Development/Assignments/01</code></li>
 <li><code>group4/Modules/03 Front End Development/Assignments/02</code></li>
 </ul>
<p>display the results in an Angular application by using<code>*ngFor</code>.</p>
 </p>