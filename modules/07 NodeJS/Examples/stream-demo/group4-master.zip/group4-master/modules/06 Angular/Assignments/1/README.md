<p>install Angular CLI using <code>npm install -g @angular/cli</code></p>
<p>create an Angular app using <code>ng new answer1</code></p>
<p>use <code>group4/Modules/01 JavaScript Programming/Assignments/3</code></p>
<p>create "x" as a "number" (using Typescript) in the script file <code>app.component.ts</code></p>
<p>display "x" in the HTML file<code>app.component.html</code> instead of logging it</p>
<p>run the application using <code>ng serve --open</code> (The "--open" or just "-o" option automatically opens your browser to http://localhost:4200)</p>