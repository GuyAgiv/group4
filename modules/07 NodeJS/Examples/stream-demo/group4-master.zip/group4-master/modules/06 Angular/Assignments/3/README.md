<p>use <code>group4/Modules/01 JavaScript Programming/Assignments/14</code></p>
<p>assign types to the variables using Typescript</p>
<p>display the results in an Angular application instead of logging or printing them</p>