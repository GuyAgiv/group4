<p>
create an Angular pipe which returns whether two strings are anagrams* of each other.
</p>
<h4>examples of anagram:</h4>
<ul>
<li>
<code>
isAnagram('rail safety', 'fairy tales')
</code>
</li>
<li>
<code>
isAnagram('RAIL! SAFETY!', 'fairy tales') 
</code>
</li>
</ul>
<p>
create an array of two strings and display a boolean indicating <code>isAnagram</code> next to them
</p>
<p>
* if a string uses the same characters as anohter then this string is an anagram
</p>