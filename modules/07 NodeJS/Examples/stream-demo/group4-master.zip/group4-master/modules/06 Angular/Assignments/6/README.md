<p>use <code>group4/Modules/03 Front End Development/Assignments/11</code></p>
<p>sort by first name using <code>Array.prototype.sort()</code>.</p>
<p>display the results in an Angular application.</p>