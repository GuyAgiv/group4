<p>use:
<ul>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/1</code></li>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/2</code></li>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/4</code></li>
 </ul>
 <p>assign types to the variables using TypeScript.</p>
<p>display the results in an Angular application instead of logging or printing them.</p>
 </p>