<p>use:
<ul>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/12</code></li>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/15</code></li>
 <li><code>group4/Modules/01 JavaScript Programming/Assignments/17</code></li>
 </ul>
<p>display the results in an Angular application.</p>
 </p>