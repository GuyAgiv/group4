<p>use <code>group4/Modules/01 JavaScript Programming/Assignments/8</code></p>
<p>create an array of people with their names and blood pressures</p>
<p>add a header "Using *ngIf"</p>
<p>loop through the array and display for each person his/her name.</p>
<p>use <code>*ngIf</code> in order to display <code>isNormal</code> according to assignment 8 condition next to the name.</p>
<p>add a header "Using Pipes"</p>
<p>loop through the array and display for each person his/her name.</p>
<p>create a pipe named <code>normalbloodpressure</code> which returns <code>isNormal</code> according to assignment 8 and display the result next to the name.</p>