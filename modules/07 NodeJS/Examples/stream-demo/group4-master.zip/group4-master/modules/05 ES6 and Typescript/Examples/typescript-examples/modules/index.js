import * as MessengerModule from './Messenger';
var whatsappMessenger = new MessengerModule.Messenger(5000);
whatsappMessenger.print();
console.log(MessengerModule.str);
