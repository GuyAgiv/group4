// const obj = {
//     a:1,
//     b:2,
//     c:3
// }

// // ES5
// function printObjectValues1(){
//     var a = obj.a;
//     var b = obj.b;
//     var c = obj.c;
//     console.log(a,b,c);
// }

// ES6
// const printObjectValues2 = () => {
//     let {a, b, c} = obj;
//     console.log(a,b,c);
// }

// const arr = [2, 5, 7];
// const printArrayValues = () => {
//     let [ , num2, num3 ] = arr;
//     console.log( num2, num3);
// }

// printArrayValues();