<p>
use*:
<ol>
<li>
<code>group4/Modules/01 JavaScript Programming/Assignments/22</code>
</li>
<li>
<code>group4/Modules/01 JavaScript Programming/Assignments/23</code>
</li>
<li>
<code>group4/Modules/01 JavaScript Programming/Assignments/24</code>
</li>
</ol>
</p>
<ul>
<li>convert the constructor to <code>Typescript Class</code> (use private, public and static)</li>
<li>add <code>types</code> (number, boolean, any, void etc.) to all variables, functions and parameters</li>
<li>use <code>interfaces</code></li>
<li>use <code>generics</code></li>
</ul>
<p>
* if you can't find a way to add TypeScript features by modifying code - add some sample code which does that. The most important thing is to experience these features.
</p>
<p>
Typescript features: <a href="https://devhints.io/typescript" target="_blank">https://devhints.io/typescript</a>
</p>