// scope
// const foo = () => {
//     if (1 === 1){
//         let x = 1;
//     }
//     console.log(x);
// }

// foo();

// no-hoisting
// console.log(y);
// const y = 2;

const z = 3;
z = 4;

// const arr = [1,2,3];
// arr[0] = 4;

// const foo = (y) => y*2;
// const x = foo(4);
// x = foo(2);