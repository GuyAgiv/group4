From Google Drive presentations:
<ol>
<li>01 ES6 & TS - Computed Property Name, for...of</li>
<li>02 ES6 & TS - Enumerable Types, Modules, Types, Classes</li>
</ol>