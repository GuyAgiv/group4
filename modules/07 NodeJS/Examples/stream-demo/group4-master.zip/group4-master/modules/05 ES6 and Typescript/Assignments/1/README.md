<p>
use*:
<ol>
<li>
<code>group4/Modules/01 JavaScript Programming/Assignments/16</code>
</li>
<li>
<code>group4/Modules/01 JavaScript Programming/Assignments/21</code>
</li>
</ol>
</p>
<ul>
<li>convert all function declarations to <code>arrow functions</code></li>
<li>convert all variable declarations to <code>let</code> and <code>const</code></li>
<li>use <code>destructuring</code></li>
<li>use <code>rest & spread</code></li>
<li>use <code>template strings</code></li>
</ul>
<p>
* if you can't find a way to add ES6 features by modifying code - add some sample code which does that. The most important thing is to experience these features.
</p>
<p>
ES6 features: <a href="https://github.com/lukehoban/es6features" target="_blank">https://github.com/lukehoban/es6features</a>
</p>