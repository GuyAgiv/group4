<h2>ITube</h2>
<div>
    <img src="58.png" alt="" />
</div>
<ul>
    <li>
        display at least 10 thumbnail YouTube videos. the thumbnails should be located inside a scrollable div (see the illustration above)
    </li>
    <li>
        when the user clicks on a thumbnail - the selected video should be played in the middle and its details should be presented below the video
    </li>
    <li>
        store all counters in localStorage so that when the user closes the browser and returns - he/she will see the stored counters
    </li>
    <li>
        <b>bonus:</b> make the page responsive: when the screen is too small for displaying the video and the thumbnails side by side - display them so that the video will be placed above the thumbnails
    </li>
</ul>