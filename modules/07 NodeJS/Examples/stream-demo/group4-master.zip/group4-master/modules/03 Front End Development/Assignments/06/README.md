<ul>
    <li>
    create a webpage with the title "My Webpage"
    </li>
    <li>
    add at least 10 different HTML tags
    </li>
    <li>
    add at least 2 different attributes to each tag
    </li>
</ul>
A list of HTML tags: <a href="http://overapi.com/html" target="_blank">http://overapi.com/html</a>