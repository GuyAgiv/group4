<p>
Create a table which contains 3 columns: "Artist", "Year" and "YouTube Video".
<p>
<p>
Add a merged column (using "colspan") with the text "My Top 5 Songs".
</p>
<p>
Fill the table with your top 5 favorite songs details: Write the artist name, mention the year and place the YouTube embedded video of the song in the last column.
</p>