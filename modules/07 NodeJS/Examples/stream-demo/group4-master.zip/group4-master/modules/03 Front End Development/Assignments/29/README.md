<p>
Create an HTML page: "password_recovery.html"
</p>
<h4>The page should include</h4>
<ul>
<li>Form</li>
<li>"Username" input field</li>
<li>2 input fields for entering email addresses</li>
<li>one input field with a checkbox</li>
<li>Submit button</li>
</ul>
<h5>Requirements:</h5>
<ul>
<li>"Username" should be disabled</li>
<li>"Username" should contain the value "John Doe"</li>
<li>Both email fields should be required</li>
<li>Checkbox should contain the label "I agree to the terms and conditions"</li>
<li>The words "terms and conditions" should open a new page in a new tab which contains some example of terms and conditions</li>
</ul>