<p>Append 3 child nodes (using Javascript) to each list item in <a href="https://github.com/JavascriptBootcamp/group4/blob/master/modules/03%20Front%20End%20Development/Assignments/07/answer.html" target="_blank">answer 07</a>. The first child node should be a button with the caption "Like". The second should be a "Comment" button and the last one a "Share" button</p>
<p>
    Change the page title (using Javascript) to "Instush"
</p>