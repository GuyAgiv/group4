<ul>
<li>
    create a task list
</li>
<li>
    each task should contain:
    <ol>
        <li>Priority (low/medium/high)</li>
        <li>Title</li>
        <li>Author</li>
        <li>Created Date</li>
        <li>Description</li>
        <li>Complexity (easy/medium/hard)</li>
        <li>Category</li>
        <li>Due Date</li>
    </ol>
</li>
<li>
the list should be sorted by priority
</li>
</ul>