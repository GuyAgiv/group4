<p>Use your answer from <code>Modules/01 JavaScript Programming/Assignments/8</code></p>
<p>Create an <code>&lt;input type="range"&gt;</code> in order to display a range of blood pressures.</p>
<p>Display a div which indicates whether the blood pressure is normal or not.</p>