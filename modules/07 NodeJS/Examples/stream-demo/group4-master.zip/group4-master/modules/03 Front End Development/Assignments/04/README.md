<ul>
    <li>create a xml page and save it as <code>answer.xml</code></li>
    <li>add tags and attributes which describe a car</li>
    <li>add at least 3 components (wheels, door, seat etc.)</li>
    <li>keep hierarchical order (for example: a <code>door</code> should contain a <code>window</code>)</li>
</ul>