<p>
Create a page "index.html" which contains 3 different pictures of flowers.
</p>
<p>
The first picture's URL should be <u>absolute</u> to the page URL.
</p>
<p>
The second picture's URL should be <u>absolute</u> to the web.
</p>
<p>
The third picture's URL should be <u>relative</u> to the project folder.
</p>
<p>
Clicking on the first two pictures should open them a new tab.
</p>
<p>
Clicking on the third picture should lead to another page you should create "not_found.html" which cotains a header "Sorry, the picture was not found".
</p>
<p>
Paths: <a href="https://www.coffeecup.com/help/articles/absolute-vs-relative-pathslinks/" target="_blank">https://www.coffeecup.com/help/articles/absolute-vs-relative-pathslinks/</a>
</p>