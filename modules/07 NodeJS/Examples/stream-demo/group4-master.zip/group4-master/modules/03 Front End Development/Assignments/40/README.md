<p>Use your answer from <code>Modules/01 JavaScript Programming/Assignments/10/question.txt</code>.</p>
<p>Accept 2 numbers (from 1 to 100) in 2 "number input fields".</p>
<p>
Iterate from the first number to the second. For each iteration, Check if the current number is even or odd, and report that to a div (e.g. "2 is even").
</p>
<p>If the second number is larger than the first - display an error in a div.</p>