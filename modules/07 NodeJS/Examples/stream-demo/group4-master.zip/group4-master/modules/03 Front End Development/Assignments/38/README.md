<p>Use your answer from <code>Modules/01 JavaScript Programming/Assignments/14</code></p>
<p>
Create a form which includes a list of your favorites (colors, food etc.) and a "Add" button.
</p>
<p>
Clicking the button will add the favorite to a <code>ol</code> list
</p>
<p>
For each choice, add a <code>li</code> to the list like: "My #1 choice is blue."
</p>