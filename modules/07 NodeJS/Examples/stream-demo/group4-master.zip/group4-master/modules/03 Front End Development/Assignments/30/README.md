<p>
Create an HTML page: "select_location.html"
</p>
<h4>The page should include</h4>
<ul>
<li>Form</li>
<li>"Continent" field which allows selecting from list</li>
<li>"Country" field which allows selecting from a drop down</li>
<li>"City" field which allows selecting from a drop down</li>
<li>Submit button</li>
</ul>
<h5>Requirements:</h5>
<ul>
<li>"Continent" should contain at least 3 continents</li>
<li>"Country" should contain at least 3 countries (not necessarily from a specific continent)</li>
<li>"City" should contain at least 3 cities (not necessarily from a specific country)</li>
</ul>