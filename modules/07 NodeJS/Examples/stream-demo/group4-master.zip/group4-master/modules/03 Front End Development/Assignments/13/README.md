<ol>
<li>
Create some links to various search engines (google, yahoo, bing etc.)
</li>
<li>
Create links to five different pages on five different websites that should all open in a new window
</li>
<li>
Create links from three different images to three different websites that should all open in a new window
</li>
</ol>