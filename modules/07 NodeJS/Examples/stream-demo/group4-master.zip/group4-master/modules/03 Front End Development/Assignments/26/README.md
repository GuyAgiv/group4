<p>Log the child nodes of each link in <a href="https://github.com/JavascriptBootcamp/group4/blob/master/modules/03%20Front%20End%20Development/Assignments/02/answer02.html" target="_blank">answer 02</a></p>
<p>Log the parent node of each image in the page</p>
<p>Log the title element's innerHTML</p>
<p>Bonus: Display the total amount of "src" attributes in the page</p>