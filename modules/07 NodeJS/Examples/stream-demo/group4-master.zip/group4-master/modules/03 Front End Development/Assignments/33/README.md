Write a script that accepts a sequence of english letters in an input field and capitalizes each letter right after it was entered.<br /><br />
Using the Javascript function <code>toUpperCase</code> is <b><u>not allowed</u></b>.<br /><br />
The complexity of the letter capitalizing function should be O(1).<br /><br />
Example:
<pre>
h
He
HEl
HELl
HELLo
HELLO
</pre>