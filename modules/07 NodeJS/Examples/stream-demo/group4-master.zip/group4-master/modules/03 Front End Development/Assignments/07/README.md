<ul>
    <li>
    create a list of movie actors
    </li>
    <li>
    add 5 different actors with their: name, age and picture
    </li>
    <li>
    link each actor name to his/her IMDB page
    </li>
</ul>