<p>Use your answer from <code>Modules/01 JavaScript Programming/Assignments/29</code></p>
<p>
Create a form with: <code>title (a text input field)</code>, <code>uploader (a drop down with fake names)</code>, <code>seconds (a number input field)</code>, and a button which executes <code>watch()</code>.
 When that method is called, it should display a div with a string like "You watched all 60 seconds of Otters Holding Hands!"</p>
 <p>Bonus: add a "plus" button which adds another a form with video details to the screen. Add a "Watch All" which display a div with all the videos and all their details.</p>