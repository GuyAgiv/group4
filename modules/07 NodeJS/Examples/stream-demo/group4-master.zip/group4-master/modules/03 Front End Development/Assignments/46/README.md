Further reading:
<ol>
    <li>
        <a href="https://javascript.info/onload-ondomcontentloaded" target="_blank">https://javascript.info/onload-ondomcontentloaded</a>
    </li>
    <li>
        <a href="https://javascript.info/cross-window-communication" target="_blank">https://javascript.info/cross-window-communication</a>
    </li>
    <li>
        <a href="https://javascript.info/bubbling-and-capturing" target="_blank">https://javascript.info/bubbling-and-capturing</a>
    </li>
</ol>