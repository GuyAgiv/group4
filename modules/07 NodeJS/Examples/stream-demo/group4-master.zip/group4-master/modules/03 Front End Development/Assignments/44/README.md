<p>Use your answer from <code>Modules/03 Front End Development/Assignments/01/</code></p>
<p>Allow adding new books using a form which contains all relevant details</p>
<p>Add a dropdown which allows sorting the books by their published date: oldest to newest and newest to oldest</p>