<ul>
    <li>create a xml page and save it as <code>answer.xml</code></li>
    <li>
    add the following tags in a hierarchical order so that <code>house</code> contains <code>room</code> which contains <code>tv</code> which contains <code>screen</code>:
    <p>
    <code>
    <pre>
    &lt;house city="Tel Aviv" country="Israel"&gt;
    &lt;/house&gt;
    &lt;room size="20"&gt;
    &lt;/room&gt;
    &lt;screen size="40"&gt;
    &lt;/screen&gt;
    &lt;room size="25"&gt;
    &lt;/room&gt;
    &lt;tv color="white"&gt;
    &lt;/tv&gt;
    </pre>
    </code>
    </p>
    </li>
</ul>