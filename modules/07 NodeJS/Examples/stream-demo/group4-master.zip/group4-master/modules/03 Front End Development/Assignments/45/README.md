<p>Use your answer from <code>Modules/03 Front End Development/Assignments/02</code></p>
<p>Allow adding new images (including URL and Wikipedia page)</p>
<p>Allow only 12 images per page. Once images amount exceeds 12, a paging menu should appear at the bottom. Clicking a page number should display the next bulk of images.</p>
<p>For example: page 2 should display images 13-24</p>