<ol>
<a href="https://thoughtbot.com/blog/transitions-and-transforms" target="_blank">
CSS Transitions and Transforms for Beginners
</a>
<a href="https://thoughtbot.com/blog/css-animation-for-beginners" target="_blank">
CSS Animation for Beginners
</a>
<a href="https://css-tricks.com/a-couple-of-use-cases-for-calc/" target="_blank">
A Couple of Use Cases for Calc()
</a>
</li>
<li>
<a href="https://theblog.adobe.com/a-comprehensive-guide-to-web-design/" target="_blank">
A Comprehensive Guide to Web Design
</a>
</li>
</ol>