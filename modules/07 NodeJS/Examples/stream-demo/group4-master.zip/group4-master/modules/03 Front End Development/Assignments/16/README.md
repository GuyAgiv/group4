<ol>
<li>
Write an article with 4 long paragraphs (at least 20 rows). The paragraphs should contain a header
</li>
<li>
Create a table of content and add anchors to it. Clicking on an anchor will make the page display the relevant paragraph
</li>
</ol>