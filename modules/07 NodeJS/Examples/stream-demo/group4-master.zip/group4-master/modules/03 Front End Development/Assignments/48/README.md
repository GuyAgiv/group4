<p>Use your answer from <code>group4/Modules/03 Front End Development/Assignments/35</code><p>
<p>add a div which wraps all images and add an ID "wrapper" to it</p>
<p>select all images that are descendants of the "wrapper" div and set their border as dark red, 2 pixels wide and solid</p>
<p>Select all images that are direct children of the link and set their border as dark green, 3px wide, solid</p>
<p>Set the page background color as light grey</p>