<p>
Create three pages and name them after songs you love.
</p>
<p>
Add to each page an audio tag which plays the song.
</p>
<p>
You can find sample mp3 audios <a href="https://sample-videos.com/download-sample-audio.php" target="_blank">here</a>.
</p>
<p>
Add controls to each audio.
</p>