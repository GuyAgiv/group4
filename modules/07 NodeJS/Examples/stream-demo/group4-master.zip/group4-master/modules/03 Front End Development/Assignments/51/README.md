<p>use your answer from <code>group4/Modules/03 Front End Development/Assignments/08</code><p>
<p>set the background image using CSS instead of using HTML.</p>
<p>
use attibute selectors in order to:
<ol>
    <li>
    select all anchors with "href" and set their color as dark green
    </li>
     <li>
    select all images of 5-stars rating and set their width and height as 200%
    </li>
     <li>
    select all images alternate texts (by selecting the "alt" attribute) which contains the word "star" and set their background color as black by using hex color ("#fff", "#ccc000" etc.)
    </li>
    <li>
select all images sources ("src" attribute) which ends with ".png" and set their width and height as 50%
    </li>
</ol>
</p>