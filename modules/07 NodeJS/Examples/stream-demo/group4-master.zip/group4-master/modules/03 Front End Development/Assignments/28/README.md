<h2><i>IMPORTANT: This exercise is not for submission</i></h2>
<p>
Open <a href="https://www.ebay.com/" target="_blank">https://www.ebay.com/</a>.
</p>
<p>
Open the browser's developer tools and <b><u>only by typing Javascript commands in the console</u></b>:
<ol>
    <li>Change the page title to "meBay"</li>
    <li>Remove the logo</li>
    <li>Fill the search input</li>
    <li>Log all input fields</li>
    <li>Log the element with the ID "gh-l-h1"</li>
    <li>Log all tags with the class "gh-td"</li>
    <li>Log all images URLs (only URLs - not the whole tag)</li>
    <li>Filter all class names which starts with "gh" and log the result</li>
    <li>
        Bonuses:
        <ul>
            <li>Scroll to the bottom of the page</li>
            <li>Change the body's background color to yellow</li>
            <li>Click on the search button</li>
        </ul>
    </li>
</p>