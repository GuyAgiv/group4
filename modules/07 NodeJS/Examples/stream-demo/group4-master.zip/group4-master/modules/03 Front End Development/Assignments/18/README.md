<p>
Create a page "index.html" which includes 3 different mp4 videos.
</p>
<p>
You can find sample mp4 videos <a href="https://sample-videos.com/index.php#sample-mp4-video" target="_blank">here</a>.
</p>
<p>
Add controls to each video.
</p>
<p>
MDN Video Tag: <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Element/video" target="_blank">https://developer.mozilla.org/en-US/docs/Web/HTML/Element/video</a>
</p>