<ol>
  <li>create a webpage with the title: "My Favorite Quotes"</li>
  <li>within a comment tag write: "A list of qoutes"</li>
  <li>change the body's background color to: "#FFCCFF"</li>
  <li>choose a header size h3, and center header</li>
  <li>write header: "Quotes:"</li>
  <li>add a horizontal rule, size 4 pixels</li>
  <li>copy and paste your favorite quotes into 5 paragraphs</li>
</ol>