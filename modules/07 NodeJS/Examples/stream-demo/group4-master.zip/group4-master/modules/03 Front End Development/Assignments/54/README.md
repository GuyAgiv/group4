<p>use your answer from <code>group4/Modules/03 Front End Development/Assignments/36</code>.</p>
<p>use a color pallete from <a href="https://color.adobe.com/create/color-wheel/" target="_blank">Kuler</a>.</p>
<p>place the board at the middle of the screen.</p>
<p>change the board structure from table-based to divs-based.</p>
<p>place X and O inside circles.</p>
<p>when "Game Over" appears, hide the rest of the elements and display only the text and a button for starting a new game.</p>
<p>add two buttons to the screen: "light" and "dark". clicking on "light" will display light colors pallete on the screen and "dark" will display dark colors.</p>