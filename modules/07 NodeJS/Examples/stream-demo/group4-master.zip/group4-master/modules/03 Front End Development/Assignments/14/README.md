<ul>
  <li>
    Create a registration form which allows to fill fields by category:
    <h3>Personal Information</h3>
    <ol>
      <li>First Name</li>
      <li>Last Name</li>
      <li>Age (with up and down buttons)</li>
    </ol>
    <h3>Credentials</h3>
    <ol>
      <li>Userame</li>
      <li>Password (*** instead of chars)</li>
    </ol>
    <h3>Contact</h3>
    <ol>
      <li>Phone Number</li>
      <li>Email Address</li>
    </ol>
    <h3>Misc</h3>
    <ol>
      <li>Comments (long text)</li>
      <li>Hobbies (choose from a list)
    </ol>
  </li>
  <li>
    choose a matching type for each field. For example: "number" for phone number etc.
  </li>
</ul>