<p>
Adjust the following page content to a pizza restaurant website.
</p>
<p>
For example: add "About Us" link to the menu, describe the restaurant's history in the content etc.
</p>
<p>
Add a logo to the beginning of the page.
</p>
<p>
The website should contain at least 3 pages. The menu should include 3 links to those pages as well.
</p>
<p>
<code>
<pre>
&lt;div id=&quot;navigation&quot;&gt;
    &lt;ul&gt;
        &lt;li&gt;&lt;a href=&quot;this.html&quot; class=&quot;link&quot;&gt;This&lt;/a&gt;&lt;/li&gt;
        &lt;li&gt;&lt;a href=&quot;that.html&quot; class=&quot;link&quot;&gt;That&lt;/a&gt;&lt;/li&gt;
        &lt;li&gt;&lt;a href=&quot;theOther.html&quot; class=&quot;link&quot;&gt;The Other&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;
&lt;/div&gt;

&lt;div id=&quot;content&quot;&gt;
    &lt;h1&gt;Ra ra banjo banjo&lt;/h1&gt;
    &lt;p&gt;Welcome to the Ra ra banjo banjo page. Ra ra banjo banjo. Ra ra banjo banjo. Ra ra banjo banjo.&lt;/p&gt;
    &lt;p&gt;(Ra ra banjo banjo)&lt;/p&gt;
&lt;/div&gt;

&lt;div id=&quot;footer&quot;&gt;
Ra ra banjo banjo
&lt;/div&gt;
</pre>
</p>