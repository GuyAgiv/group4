<ul>
    <li>create a webpage and set its title to "Books | Favorites"</li>
    <li>add a &lt;h1&gt; header "My Top 5 Books:" to the &lt;body&gt;</li>
    <li>
        for each book of the five use:
        <ol>
            <li>&lt;h1&gt; to describe its title</li>
            <li>&lt;h2&gt; to mention its authors</li>
            <li>&lt;h3&gt; to describe its published date</li>
            <li>&lt;h4&gt; to mention its publishers</li>
            <li>&lt;h5&gt; to mention its page count</li>
            <li>&lt;p&gt; to write your comments about the book</li>
        </ol>
    </li>
    <li>save the file as <code>answer.html</code></li>
</ul>