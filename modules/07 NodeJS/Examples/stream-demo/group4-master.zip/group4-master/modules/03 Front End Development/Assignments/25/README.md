<p>Build a website of To-Do tasks.</p>
<p>The main page should include a list with titles of To-Do tasks.</p>
<p>Display at least 5 tasks.</p>
<p>Clicking a task should link to a page which contains: title, description, due date, assignee & status (which is represented by an image - one image for "done" and one for "in progress" - choose one randomly for each task).</p>
<p>Add "id" & "class" attributes to each HTML tag you add.</p>