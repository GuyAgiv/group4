<p>Use your answer from <code>group4/Modules/03 Front End Development/Assignments/05</code><p>
<p>add a <code>&ltspan&gt;</code> HTML tag to each word in the code.</p>
<p>set the color of all <code>var</code> keywords as dark red.</p>
<p>set the color of all variables ("console", "arr", "filtered" etc.) as dark green.</p>
<p>set the color of all equal signs as dark blue.</p>
<p>set the color of all <code>commas</code> as dark grey.</p>