Create two objects of two bank accounts with the keys: owner, address and balance.<br /><br />
Create a function "Withdraw" which accepts an amount as parameter. The function should withdraw the amount from the balance and print the modified balance.<br /><br />
Run the function twice: once with the context of the first bank account and once with the other bank account.