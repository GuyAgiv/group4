<ul>
    <li>
    create a list of recipes using the &lt;ul&gt; tag
    </li>
    <li>
    add to each recipe a list of ingredients
    </li>
    <li>
    add to each recipe the time of cooking
    </li>
    <li>
    add to each a stars rating (1-5) which will be displayed using &lt;img&gt; tags
    </li>
    <li>
    add to the top of the page a &lt;ol&gt; tag which contains the name of the recipe and a link and an anchor which links to its location in the page
    </li>
    <li>
    add to the bottom of the page a link to a supermarket website. The website should get opened in a new tab
    </li>
    <li>
    add a background image of vegtables to the &lt;body&gt; element
    </li>
</ul>