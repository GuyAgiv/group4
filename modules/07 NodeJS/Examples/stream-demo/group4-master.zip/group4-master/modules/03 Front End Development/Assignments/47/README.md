<p>Use your answer from <code>group4/Modules/03 Front End Development/Assignments/01</code></p>

<p>link a stylesheet named "linked.css" to the page. Set the page background color as dark blue inside that stylesheet.</p>

<p>embed a stylesheet to the page and set the page background color as dark green.</p>

<p>set an inline style to the body which changes its font color to white</p>

<p>
set inline styles to the headers which changes their font sizes to:
<ul>
    <li>
h1 - 24px
    </li>
    <li>
h2 - 20px
    </li>
    <li>
h3 - 16px
    </li>
    <li>
h4 - 12px
    </li>
    <li>
h5 - 8px
    </li>
</ul>
</p>