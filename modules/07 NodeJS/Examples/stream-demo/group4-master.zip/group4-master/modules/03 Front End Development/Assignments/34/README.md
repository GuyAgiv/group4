Write a script that accepts 10 words in 10 input fields and display a div (after clicking a submit button) which includes the words after removing all duplicate words and sorting them alphanumerically.<br /><br />
Suppose the following input is supplied to the program:<br />
<code>hello world and practice makes perfect and hello world again</code><br /><br />
Then, the output should be:<br />
<code>again and hello makes perfect practice world</code>