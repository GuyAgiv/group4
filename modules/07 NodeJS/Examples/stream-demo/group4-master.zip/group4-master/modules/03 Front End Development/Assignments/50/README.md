<p>use your answer from <code>group4/Modules/03 Front End Development/Assignments/07</code><p>
<p>use Sibling Selector in order to add a top border to each list item (except from the first one).</p>
<p>set the border as "DarkSlateGrey", 3 pixels wide, dashed</p>
<p>set the page's background color as "LightSlateGray"</p>
<p>add the universal selector as set all texts colors as whites</p>