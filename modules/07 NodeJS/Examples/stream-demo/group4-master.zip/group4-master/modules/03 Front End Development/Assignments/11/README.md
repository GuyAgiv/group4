<ul>
<li>
    create a "Contact Persons" table
</li>
<li>
    each row should contain:
    <ol>
        <li>First Name</li>
        <li>Last Name</li>
        <li>Address</li>
        <li>Phone Number</li>
        <li>Email Address</li>
    </ol>
</li>
<li>
    the table should be sorted by first name
</li>
<li>
  each column should contain a header with the background color of "#FFCCFF"
</li>
<li>
  clicking the email address should open an Email Software (Outlook etc.)
</li>
</ul>