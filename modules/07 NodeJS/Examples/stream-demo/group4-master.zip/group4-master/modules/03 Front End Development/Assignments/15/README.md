<ul>
  <li>
  create a trivia quiz
  </li>
  <li>
  add 10 questions. Each question should contain 4 possible answers
  </li>
  <li>
  add a submit button
  </li>
  <li>
  add an hidden input field "ts" with the value of "1547375825757"
  </li>
  <li>
  submitting the quiz should post the data to the following URL: <code>http://localhost:3000/quiz</code>
  </li>
</ul>