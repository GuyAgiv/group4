<ul>
    <li>create a webpage and set its title to "Images | Favorites"</li>
    <li>
        add 10 pictures which were taken in places you have visited before. The pictures source should be remote (<code>http://domain.com/pic.jpg</code> etc.)
    </li>
    <li>
        link each picture to the place's Wikipedia page. For example: a picture of Eiffel Tower should link to: <code>https://en.wikipedia.org/wiki/Eiffel_Tower</code>
    </li>
    <li>save the file as <code>answer.html</code></li>
</ul>