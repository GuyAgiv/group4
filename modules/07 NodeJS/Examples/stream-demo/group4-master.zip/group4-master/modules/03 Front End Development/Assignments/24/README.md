<p>Build an HTML website.</p>
<p>
The website should contain:
<ul>
<li>
At least 5 pages
</li>
<li>
At least 3 images
</li>
<li>
At least 7 links
</li>
<li>
At least 1 table
</li>
<li>
At least 1 video
</li>
<li>
At least 1 YouTube video
</li>
<li>
At least 10 divs
</li>
</ul>
</p>
<p>Add "id" & "class" attributes to each HTML tag you add.</p>