<ol>
<li>
<a href="https://www.isoc.org.il/event/so-what-is-css" target="_blank">
Video: What is CSS?
</a>
</li>
<li>
<a href="http://dorward.me.uk/www/css/inheritance/" target="_blank">
CSS Inheritence
</a>
</li>
<li>
<a href="http://nthmaster.com/" target="_blank">
Mastering the :nth-child
</a>
</li>
<li>
<a href="https://css-tricks.com/the-lengths-of-css/" target="_blank">
The Lengths of CSS
</a>
</li>
</ol>