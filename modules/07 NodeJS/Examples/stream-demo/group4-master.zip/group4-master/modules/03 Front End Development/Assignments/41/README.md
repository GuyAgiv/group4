<p>Use your answer from <code>Modules/01 JavaScript Programming/Assignments/13</code></p>
<p>Accepts a sequence of english letters in an input field.<br /><br />
<p>Display a div which indicates if the input value is a palindrome right after each letter insertion.</p>