<p>
Create a table which contains 3 columns: "HaAvoda", "Likud" and "Kulanu".
<p>
<p>
Add a merged column (using "colspan") with the text "3 Parties In One Place".
</p>
<p>
Fill each column an IFrame which includes the website ("https://www.kulanu-party.co.il" inside the first column, "https://www.likud.org.il" inside the second and "https://www.kulanu-party.co.il" inside the third one).
</p>
