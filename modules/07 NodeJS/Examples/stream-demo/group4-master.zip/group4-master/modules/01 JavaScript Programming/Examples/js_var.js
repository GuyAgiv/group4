var x = 2;
var y = '3';
console.log(x + +y);

var result = (2 + 3) * 4;
console.log(result);
console.log(x);

var x = 3;
console.log(x < 5 || x > 6 && x > 1 && x < 10 && x < 0);

var x = "some string";
x = x || "some other string";

var x = 4;
console.log(x !== 3);

var x = " 0xF";
console.log(parseInt(x, 10));