
substring מחזירה את התווים שבין שני  האינדקסים שצוינו , אינדקס התחלה ואינדקס הסוף

var someText="Here I want to extract this text !!! "

//23 to 31
var result =someText.substring(23,31);


  console.log(result);
