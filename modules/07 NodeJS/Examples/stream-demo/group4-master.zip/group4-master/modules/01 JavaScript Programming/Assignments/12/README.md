<p>Write a function that given a string of words, returns a string composed of the even words (1-based) from the original string:</p>
<code>
<pre>
function evenWords(str) {
  ...
}
</pre>
</code>
<p>Example input: <code>'aaa bbbb asda 1331 ewe'</code></p>
<p>Example output: <code>'bbbb 1331'</code></p>
