הפונקציה מחפשת ערך שנתנו לה ומחזירה מחרוזת חדשה שבה מוחלף הערך שנתנו לה. replace

var str = 'hello word';
var result = str.replace('llo', 'bo')
console.log(result);
