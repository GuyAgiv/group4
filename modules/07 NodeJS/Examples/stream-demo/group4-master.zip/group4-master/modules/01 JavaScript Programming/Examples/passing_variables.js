// var mazda = {
//     color: "white",
//     model: "2015",
//     km: "25000",
//     isForSell: false
// };

// var driver = "Amitay";
// console.log("BEFORE - Driver is " + driver);
// function changeDriver(driver){
//     driver = "David";
// }
// changeDriver(driver);
// console.log("AFTER - Driver is " + driver);

// console.log("BEFORE - Mazda's color is " + mazda.color);
// function changeColor(car, color){
//     car.color = color;
// }
// changeColor(mazda, "black")
// console.log("AFTER - Mazda's color is " + mazda.color);

// var car = {
//     color: "white",
//     model: "2015",
//     km: "25000",
//     isForSell: false
// };

// var shaisCar = car;
// car.color = "yellow";
// console.log(shaisCar.color);

var num = 4;
var num2 = num;
num = 99;
console.log(num2);