var shirtSizes = ['xs','s','m','l','xl','xxl'];

for (var i=0;i<shirtSizes.length;i++){
    for (var j=0; j<shirtSizes.length;j++){
        console.log(shirtSizes[i]);
    }
}