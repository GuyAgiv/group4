/*
includes() method on array
כאשר מופעלת על מערך: מקבלת פרמטר ובודקת האם הפרמטר הזה זהה ללפחות אחד מאיברי המערך שקורא לה.
אם כן - מחזירה true
אחרת מחזירה  false
*/


var names = ["Beny Man", "David Good", "Koko Comipoki", "Kuzinaki Kuzuki"];
var result = names.includes("Koko Comipoki");
//var result = names.includes("Some Name");

console.log(result);
