Create a queue data structure.<br>
The queue should be a constructor with methods <code>add</code> (add an item to the queue) and <code>remove</code> (remove and return an item).<br>
<h4>Example</h4>
<code>
    <pre>
    var queue = new Queue();<br>
    queue.add(1);<br>
    queue.remove();<br>
    </pre>
</code>
<h4>Will return</h4>
<code>1</code>