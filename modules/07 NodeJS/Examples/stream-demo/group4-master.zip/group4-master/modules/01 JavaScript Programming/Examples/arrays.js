var arr = [1, 2, 5, 7];
// var arr2 = [9 , 11 , 13 , 14];
// splice
// console.log('before splice', arr);
// arr.splice(2, 1);
// console.log('after splice', arr);
// concat
//  var concat = arr.concat(arr2);
 //console.log(concat);
// var filtered = concat.filter(function(item){
//     return item % 2 === 0;
// }); 
// for instead of filter
// var filtered = [];
// for (var i=0; i<concat.length; i++){
//     if (concat[i] % 2 === 0){
//         filtered.push(concat[i]);
//     }
// }
// console.log(filtered);
// var removed = arr.shift();
// console.log('Array:', arr, 'Removed:', removed);
// var arrSize = arr.unshift(999);
// console.log('Array:', arr, 'New Array Size:', arrSize);
// Slice
// var result = arr.slice(0,3);
// console.log(result);
// console.log(arr);
// every
// var result = arr.every(function(item){
//     return item < 0;
// });
// console.log(result);
// some
// var result = arr.some(function(item){
//     return item > 9;
// });
// console.log(result);