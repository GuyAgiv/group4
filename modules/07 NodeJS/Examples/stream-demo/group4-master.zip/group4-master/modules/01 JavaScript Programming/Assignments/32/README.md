<p>use a stack and a queue in order to check if a given string is a palindrome.</p>
<p>for example, "abccba" is palindrome, but "abccb" is not palindrome.</p>