String.trim()

פונקציה של מחרוזת, הפונקציה מחזירה את המחרוזת ללא רווחים מיותרים לפני ואחרי


var greeting = '   Hello world!   ';

console.log(greeting.trim());   // expected output: "Hello world!";
