Write a JavaScript function that displays the current day and time in the following format:<br><br>
Today is Tuesday. <br>
Current time is 22:30:38<br><br>
display one example by executing this function using IIFE.<br><br>
<h2>Related Links:</h2>
<a href="https://developer.mozilla.org/en-US/docs/Glossary/IIFE" target="_blank">
https://developer.mozilla.org/en-US/docs/Glossary/IIFE
</a>