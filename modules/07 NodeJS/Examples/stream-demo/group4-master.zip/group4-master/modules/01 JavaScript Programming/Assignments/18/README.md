<ul>
 <li>Write a function called <code>register</code> that takes a shopping cart object. The object contains item names and prices (itemName: itemPrice). The function should return the total price of the shopping cart.

 </li><li>Example
<pre>// Input
var cart = {  
  apple: "1.25",
  candy: ".99",
  water: "25.01",
  carrot: "0.60",
  umbrella: "10.34",
  proteinShake: "22.36"
};

// Output
register(cart)); // 60.55
</pre>
</li>

</ul>