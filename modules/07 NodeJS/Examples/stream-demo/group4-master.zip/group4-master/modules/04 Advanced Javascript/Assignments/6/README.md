<p>use <code>group4/Modules/04 Advanced Javascript/Assignments/2</code></p>
<p>add a new option for <code>storageType</code>: "cookie"</p>
<p>implement all methods (get, set, remove, clear) using <code>document.cookies</code><p>
<p>for example:
<code>
<pre>
var cStorage = new Storage("cookie");
cStorage.set("someKey3", "someValue3");
console.log(cStorage.getItem("someKey3")); // should print "someValue3"
</pre>
</code>
</p>