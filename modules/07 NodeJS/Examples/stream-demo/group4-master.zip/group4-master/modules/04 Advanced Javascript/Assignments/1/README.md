<p>modify the constructors in following scripts so that they will contain <code>Prototype</code> assignments instead of <code>this</code> assignments:</p>
<ol>
    <li>group4/Modules/01 JavaScript Programming/Assignments/27</li>
    <li>group4/Modules/01 JavaScript Programming/Assignments/28</li>
    <li>group4/Modules/01 JavaScript Programming/Assignments/29</li>
</ol>