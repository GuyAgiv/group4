<p>create a function named <code>mySliceFunction</code> which can be executed on an instance of array.</p>
<p>The function should slice an array to according to the provided boundaries.</p>
<h4>For Example</h4>
<code>
<pre>
var arr = [1, 2, 5, 7];
var sliced = arr.mySliceFunction(1,2);
console.log(sliced);
</pre>
</code>
<h5>should return:</h5>
<code>
[ 2, 5 ]
</code>