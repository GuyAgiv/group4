<ol>
    <li>
        <a href="https://coryrylan.com/blog/javascript-es6-class-syntax" target="_blank">
            JavaScript ES6 Class Syntax
        </a>
    </li>
    <li>
        <a href="https://github.com/lukehoban/es6features">
            Overview of ECMAScript 6 features
        </a>
    </li>
    <li>
        <a href="https://developers.google.com/web/ilt/pwa/working-with-indexeddb">
            Working with IndexedDB
        </a>
    </li>
</ol>