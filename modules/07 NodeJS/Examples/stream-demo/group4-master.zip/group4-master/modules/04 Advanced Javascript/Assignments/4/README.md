<p>create two functions named <code>max</code> and <code>min</code> which can be executed on an instance of array.</p>
<p>The functions should obtain the min or max element of a JavaScript Array.</p>
<h4>For Example</h4>
<code>
<pre>
var arr = [1, 22, 50, 7];
var minimum = arr.min();
var maximum = arr.max();
console.log("Minimum:", minimum, "Maximum:", maximum);
</pre>
</code>
<h5>should return:</h5>
<code>
Minimum: 1 Maximum: 50
</code>