<p>use <code>group4/Modules/03 Front End Development/Assignments/56</code>.</p>
<p>load the pictures by fetching a list of them using an AJAX request to: <a href="https://picsum.photos/list">https://picsum.photos/list</a> and rendering images with the following template <code>https://picsum.photos/200/300?image={id}</code> ("id" is part of the JSON).</p>
<p>add a link to the post by using "post_url" from the JSON.</p>
<p>while pictures are loading - display a loading indicator.</p>
